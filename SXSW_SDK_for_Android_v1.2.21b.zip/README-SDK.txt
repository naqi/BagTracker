ZOS Discrete Agent (ZDA) SDK for Android

Version 1.2.21

Summary:
The ZOS Discrete Agent SDK allows mobile developers to easily integrate the capabilities of the ZOS platform into their application via a lightweight module with APIs. These capabilities include:
� Location Acquisition and Lookup
� Message Event Notification
� Location Event Notification
� Generic XML Transport Interface
� Version Check/Query
� Opt-In Registration mechanism


Requirements:
The ZDA SDK requires Android OS version 1.6 or higher.
   

Contents:
� doc
  - api folder: This folder contains the API documentation (Javadoc format) for the ZDA classes and methods
  - ZDA_SDK_for_Android-Getting_Started.pdf: ZDA Getting Started Guide for Android ZDA Developers
  - ZOS_Discrete_Agent_SDK_Overview.pdf : Contains a high-level overview of the ZDA mobile SDK.


� bin
  - ZDA.jar: The ZDA client and service library files that are integrated into your development environment/mobile application.


� zdaExamples: An eclipse project to demonstrate the zda APIs with a basic UI


� zdaInboxExample: An eclipse project to demonstrate the zda and Web Inbox integration


� Release-Notes.txt: Contains release notes for the version of the SDK

� ZDA_Developer_EULA.pdf : The Developer End User License Agreement
