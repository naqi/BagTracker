/*
*
* $HeadURL: https://svn.zoscomm.com:8443/svn/ZDA_Java/branches/1_2/Android/zdaExamples/src/com/zda/library/examples/zdaExamples.java $
* $Rev: 150 $
* $Author: pcudmore $
* $Date: 2012-01-27 14:31:03 +0000 (Fri, 27 Jan 2012) $
*
* Copyright Zos Communications LLC, (c) 2012
*
*  ZOS Communications, LLC (�ZOS�) grants you a nonexclusive copyright license
*  to use all programming code examples from which you can generate similar 
*  function tailored to your own specific needs.
* 
*  All sample code is provided by ZOS for illustrative purposes only. These 
*  examples have not been thoroughly tested under all conditions. ZOS, 
*  therefore, cannot guarantee or imply reliability, serviceability, or 
*  function of these *programs.
* 
*  All programs contained herein are provided to you "AS IS" without any 
*  warranties of any kind. The implied warranties of non-infringement, 
*  merchantability and fitness for a particular purpose are expressly 
*  disclaimed.
*
*/
package com.zda.library.examples;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.RemoteException;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.zoscomm.zda.client.api.GeoLocation;
import com.zoscomm.zda.client.api.ZDAClassFactory;
import com.zoscomm.zda.client.api.ZDAEventListener;
import com.zoscomm.zda.client.api.ZDAEventService;

/**
 * This is a very simple test application that presents 5 buttons to the user.
 * Initially only the 'Get Version' and 'Authenticate Token' buttons are
 * visible but once a token has been obtained the other buttons are shown.
 * 
 * This app allows you to very simply exercise the location update, location
 * shot and send XML API functions.   Results returned from the ZDA are just
 * displayed using toasts.
 */
public class zdaExamples extends Activity
{
    /**********************************************************/
    private ZDAEventService zdaService = null;
    private String userToken = null;
    /**********************************************************/

    /**********************************************************/
    private final static int SHOW_TOAST_EVENT = 1;
    private final static int ENABLE_BUTTONS_EVENT = 2;
    /**********************************************************/

    /********** Location Shot timeout and accuracy ***********/
    private final static int TIMEOUT = 60; // Seconds
    private final static int ACCURACY = 50; // Meters
    /**********************************************************/

    /********* Credentials - replace these with yours *********/
    private final static String APPLICATION_API = "MyApiKey";
    private final static String APPLICATION_PASSWORD = "MySuperSecretPSW";
    /**********************************************************/

    /********* Buttons ****************************************/
    private Button buttonGetVersion;
    private Button buttonEnableLocationListener;
    private Button buttonLocalSearch;
    private Button buttonRequestToken;
    private Button buttonLocationShot;
    /*********************************************************/

    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        zdaService = ZDAClassFactory.getEventService(this);
        initButtons();
    }

    /**
     * Initialize the buttons. Sets the OnClickListener for each one.
     * 
     * To start with, only the get version and request token buttons are visible.  
     * Once you have a valid token, the other buttons will be enabled.
     */
    private void initButtons()
    {
        buttonGetVersion = (Button) this.findViewById(R.id.buttonGetVersion);
        buttonGetVersion.setOnClickListener(new Button.OnClickListener()
        {
            public void onClick(View v)
            {
                try
                {
                    if (zdaService != null)
                    {
                        zdaService.getVersion(zdaListener);
                    }
                    else
                    {
                        Toast.makeText(zdaExamples.this, "Failed connect to zda service", Toast.LENGTH_LONG).show();
                    }
                }
                catch (RemoteException e)
                {
                }
            }
        });
        
        buttonRequestToken = (Button) this.findViewById(R.id.buttonRequestToken);
        buttonRequestToken.setOnClickListener(new Button.OnClickListener()
        {
            public void onClick(View v)
            {
                try
                {
                    if (zdaService != null)
                    {
                        zdaService.authenticateUser(APPLICATION_API, APPLICATION_PASSWORD, zdaListener);
                    }
                    else
                    {
                        Toast.makeText(zdaExamples.this, "Failed connect to zda service", Toast.LENGTH_LONG).show();
                    }
                }
                catch (RemoteException e)
                {
                }
            }
        });

        buttonEnableLocationListener = (Button) this.findViewById(R.id.buttonEnableLocationListener);
        buttonEnableLocationListener.setOnClickListener(new Button.OnClickListener()
        {
            public void onClick(View v)
            {
                try
                {
                    // This is effectively a toggle button.  If the location listener has not yet been
                    // added then it adds it, otherwise it removes it.
                    if (buttonEnableLocationListener.getText().toString()
                            .equalsIgnoreCase(getResources().getString(R.string.DisableLocationListenerString)))
                    {
                        buttonEnableLocationListener.setText(R.string.EnableLocationListenerString);
                        zdaService.removeLocationUpdateListener(userToken, zdaListener);
                    }
                    else
                    {
                        buttonEnableLocationListener.setText(R.string.DisableLocationListenerString);
                        zdaService.addLocationUpdateListener(userToken, zdaListener);
                    }
                }
                catch (RemoteException e)
                {
                }
            }
        });

        buttonLocalSearch = (Button) this.findViewById(R.id.buttonLocalSearch);
        buttonLocalSearch.setOnClickListener(new Button.OnClickListener()
        {
            public void onClick(View v)
            {
                try
                {
                    // Use the XML passthrough interface to do a local search for pizza near 34.41418,-119.6886.
                    String msg = "<request><action>localsearch</action><search>pizza</search><coordinates><latitude>34.41418</latitude><longitude>-119.6886</longitude></coordinates></request>";
                    int id = zdaService.sendXml(userToken, msg, zdaListener);
                }
                catch (RemoteException e)
                {
                }
            }
        });

        buttonLocationShot = (Button) this.findViewById(R.id.buttonLocationShot);
        buttonLocationShot.setOnClickListener(new Button.OnClickListener()
        {
            public void onClick(View v)
            {
                try
                {
                    zdaService.requestLocationShot(userToken, ACCURACY, TIMEOUT, zdaListener);
                }
                catch (RemoteException e)
                {
                }
            }
        });
    }

    /**
     * Makes the add location listener, local search and location shot buttons visible.
     */
    private void enableButtons()
    {
        buttonEnableLocationListener.setVisibility(Button.VISIBLE);
        buttonLocalSearch.setVisibility(Button.VISIBLE);
        buttonLocationShot.setVisibility(Button.VISIBLE);
    }
    
    /**
     * Used to update the UI in the correct thread.
     */
    private Handler mHandler = new Handler()
    {
        public void handleMessage(Message msg)
        {
            switch (msg.what)
            {
            case SHOW_TOAST_EVENT:
                Toast.makeText(zdaExamples.this, (String) msg.obj, Toast.LENGTH_LONG).show();
                break;
            case ENABLE_BUTTONS_EVENT:
                enableButtons();
                break;
            default:
                super.handleMessage(msg);
            }
        }
    };

    /**
     * This implementation of ZDAEventListener is used to receive callbacks from the zda service.
     */
    public ZDAEventListener zdaListener = new ZDAEventListener.Stub()
    {
        public void onVersionResponse(String version) throws RemoteException
        {
            String toastString = "ZDA Version: " + version;
            mHandler.sendMessage(mHandler.obtainMessage(SHOW_TOAST_EVENT, toastString));
        }

        public void onAuthenticationComplete(String token) throws RemoteException
        {
            userToken = token;
            // Now that we have a token, we can show the other buttons.
            mHandler.sendMessage(mHandler.obtainMessage(ENABLE_BUTTONS_EVENT));
        }

        public void onError(int errorCode, String reason) throws RemoteException
        {
            String toastString = "Error: " + errorCode + "  Reason: " + reason;
            mHandler.sendMessage(mHandler.obtainMessage(SHOW_TOAST_EVENT, toastString));
        }

        public void onLocationShotResponse(GeoLocation location) throws RemoteException
        {
            String toastString = "Location Shot Response:\n\tLat: " + location.getLatitude() + "\n\tLong: "
                    + location.getLongitude() + "\n\tAccuracy: " + location.getAccuracy() + "m" + "\n\tMethod: "
                    + location.getMethod();
            mHandler.sendMessage(mHandler.obtainMessage(SHOW_TOAST_EVENT, toastString));
        }

        public void onLocationUpdate(GeoLocation location) throws RemoteException
        {
            String toastString = "New Location Update:\n\tLat: " + location.getLatitude() + "\n\tLong: "
                    + location.getLongitude() + "\n\tAccuracy: " + location.getAccuracy() + "m" + "\n\tMethod: "
                    + location.getMethod();
            mHandler.sendMessage(mHandler.obtainMessage(SHOW_TOAST_EVENT, toastString));
        }
        
        public void onXmlResponse(int id, String reponse) throws RemoteException
        {
            String toastString = "Post msg response: " + reponse;
            mHandler.sendMessage(mHandler.obtainMessage(SHOW_TOAST_EVENT, toastString));
        }

        public void onMessageNotify(int count) throws RemoteException
        {
            // Not used.
        }
        
        public void onComplete(int action, String param) throws RemoteException
        {
            // Not used.
        }
    };
}