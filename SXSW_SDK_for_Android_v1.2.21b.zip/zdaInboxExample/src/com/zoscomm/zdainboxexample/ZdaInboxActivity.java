/*
 * Copyright Zos Communications LLC, (c) 2012
 *
 *  ZOS Communications, LLC (�ZOS�) grants you a nonexclusive copyright license
 *  to use all programming code examples from which you can generate similar 
 *  function tailored to your own specific needs.
 * 
 *  All sample code is provided by ZOS for illustrative purposes only. These 
 *  examples have not been thoroughly tested under all conditions. ZOS, 
 *  therefore, cannot guarantee or imply reliability, serviceability, or 
 *  function of these *programs.
 * 
 *  All programs contained herein are provided to you "AS IS" without any 
 *  warranties of any kind. The implied warranties of non-infringement, 
 *  merchantability and fitness for a particular purpose are expressly 
 *  disclaimed.
 *
 */
package com.zoscomm.zdainboxexample;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.os.Message;
import android.webkit.WebView;
import android.webkit.WebViewClient;

public class ZdaInboxActivity extends Activity
{
    @SuppressLint("SetJavaScriptEnabled")
    @Override
    public void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_zda_inbox);
        
        final WebView webview = (WebView) findViewById(R.id.webview);
        webview.getSettings().setJavaScriptEnabled(true);
        webview.setWebViewClient(new WebViewClient() 
        {     
            @Override
            public void onFormResubmission(WebView view, Message dontResend, Message resend)
            {
                resend.sendToTarget();
            }
        });
        
        // Check whether we've been given the guid of a specific message.
        int messageCount = 0;
        String messageGuids = null;
        Bundle extras = getIntent().getExtras();
        if (extras != null)
        {
            messageCount = extras.getInt("message_count");
            if (messageCount == 1)
            {
                messageGuids = extras.getString("guids");
            }
        }
        
        ZdaInboxHelper.getInstance().showWebInbox(webview, messageGuids);
        
        ZdaBroadcastReceiver.removeNotification(this);
    }

    @Override
    protected void onDestroy()
    {
        ZdaInboxHelper.getInstance().cancelShowWebInbox();
        super.onDestroy();
    }
}
