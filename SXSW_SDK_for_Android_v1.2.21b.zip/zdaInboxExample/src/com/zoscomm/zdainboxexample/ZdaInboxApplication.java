/*
 * Copyright Zos Communications LLC, (c) 2012
 *
 *  ZOS Communications, LLC (�ZOS�) grants you a nonexclusive copyright license
 *  to use all programming code examples from which you can generate similar 
 *  function tailored to your own specific needs.
 * 
 *  All sample code is provided by ZOS for illustrative purposes only. These 
 *  examples have not been thoroughly tested under all conditions. ZOS, 
 *  therefore, cannot guarantee or imply reliability, serviceability, or 
 *  function of these *programs.
 * 
 *  All programs contained herein are provided to you "AS IS" without any 
 *  warranties of any kind. The implied warranties of non-infringement, 
 *  merchantability and fitness for a particular purpose are expressly 
 *  disclaimed.
 *
 */
package com.zoscomm.zdainboxexample;

import android.app.Application;

public class ZdaInboxApplication extends Application
{
    public static final String API_KEY = "YOUR-API-KEY-HERE";
    public static final String PASSWORD = "YOUR-API-PASSWORD-HERE";
    
    @Override
    public void onCreate()
    {
        super.onCreate();
        ZdaInboxHelper.getInstance().initialize(this, API_KEY, PASSWORD);
    }
}
