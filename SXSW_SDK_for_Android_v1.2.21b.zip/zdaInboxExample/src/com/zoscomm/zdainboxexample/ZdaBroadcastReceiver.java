/*
 * Copyright Zos Communications LLC, (c) 2012
 *
 *  ZOS Communications, LLC (�ZOS�) grants you a nonexclusive copyright license
 *  to use all programming code examples from which you can generate similar 
 *  function tailored to your own specific needs.
 * 
 *  All sample code is provided by ZOS for illustrative purposes only. These 
 *  examples have not been thoroughly tested under all conditions. ZOS, 
 *  therefore, cannot guarantee or imply reliability, serviceability, or 
 *  function of these *programs.
 * 
 *  All programs contained herein are provided to you "AS IS" without any 
 *  warranties of any kind. The implied warranties of non-infringement, 
 *  merchantability and fitness for a particular purpose are expressly 
 *  disclaimed.
 *
 */
package com.zoscomm.zdainboxexample;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;

public class ZdaBroadcastReceiver extends BroadcastReceiver
{
    @SuppressWarnings("deprecation")
    @Override
    public void onReceive(Context context, Intent intent)
    {
     // NOTE : We only handle one type of message ("com.zoscomm.zda.NEW_MESSAGES_AVAILABLE")
        //        so no need to check it here.
               
        // Compare the client id to our API key - if it matches we can handle this message.
        String clientID = intent.getStringExtra("client_id");
        if (clientID != null && clientID.equals(ZdaInboxApplication.API_KEY))
        {
            // Get the notification manager.
            NotificationManager notificationManager 
              = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

            int messageCount = intent.getIntExtra("message_count", 0);
            String guids = intent.getStringExtra("guids");
            if (messageCount > 0)
            {
                // Set up an intent that will be sent if the user clicks the notification.
                Intent displayIntent = new Intent(context, ZdaInboxActivity.class);
                displayIntent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                displayIntent.putExtra("message_count", messageCount);
                if (guids != null)
                    displayIntent.putExtra("guids", guids);
                PendingIntent launchIntent = PendingIntent.getActivity(context, 0, displayIntent, PendingIntent.FLAG_UPDATE_CURRENT);
                
                // Set up notification resources.
                int icon = R.drawable.notification;
                Resources res = context.getResources();
                StringBuilder tickerText = new StringBuilder();
                tickerText.append("You have ");
                tickerText.append(messageCount);
                tickerText.append(" new message(s)");
                String expandedText = tickerText.toString();
                String expandedTitle = res.getString(R.string.app_name);
                long when = System.currentTimeMillis();
                
                // Create the notification.
                Notification notification = new Notification(icon, tickerText, when);
                notification.setLatestEventInfo(context, expandedTitle, expandedText, launchIntent);
                
                notificationManager.notify(1, notification);
            }
            else
            {
                notificationManager.cancel(1);
            }
        }
    }

    /**
     * Removes our new message notification (if exists).
     */
    public static void removeNotification(Context context)
    {
        // Get the notification manager.
        NotificationManager notificationManager 
          = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        
        notificationManager.cancel(1);
    }
}
