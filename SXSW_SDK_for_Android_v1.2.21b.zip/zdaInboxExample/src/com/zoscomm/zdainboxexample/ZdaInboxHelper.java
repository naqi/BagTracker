/*
 * Copyright Zos Communications LLC, (c) 2012
 *
 *  ZOS Communications, LLC (�ZOS�) grants you a nonexclusive copyright license
 *  to use all programming code examples from which you can generate similar 
 *  function tailored to your own specific needs.
 * 
 *  All sample code is provided by ZOS for illustrative purposes only. These 
 *  examples have not been thoroughly tested under all conditions. ZOS, 
 *  therefore, cannot guarantee or imply reliability, serviceability, or 
 *  function of these *programs.
 * 
 *  All programs contained herein are provided to you "AS IS" without any 
 *  warranties of any kind. The implied warranties of non-infringement, 
 *  merchantability and fitness for a particular purpose are expressly 
 *  disclaimed.
 *
 */
package com.zoscomm.zdainboxexample;

import android.content.Context;
import android.os.RemoteException;
import android.webkit.WebView;

import com.zoscomm.zda.client.api.GeoLocation;
import com.zoscomm.zda.client.api.ZDAClassFactory;
import com.zoscomm.zda.client.api.ZDAEventListener;
import com.zoscomm.zda.client.api.ZDAEventService;

public class ZdaInboxHelper extends ZDAEventListener.Stub
{
    /** This HTML is displayed if we haven't got the GUID yet. It is replaced with
     *  the inbox once the GUID is available. */
    private static final String HTML_LOADING = "<html><body><table style=\"height:100%;width:100%;\"><tr><td style=\"vertical-align:middle;text-align:center;\">The inbox is loading, please wait...</td></tr></table></body></html>";
    /** This HTML is displayed if initialize() hasn't been called (integration error). */
    private static final String HTML_ERROR = "<html><body><table style=\"height:100%;width:100%;\"><tr><td style=\"vertical-align:middle;text-align:center;\">This component has not been initialized</td></tr></table></body></html>";
    private static final String DEVICE_GUID_PROPERTY = "guid";
    private static final String INBOX_URL_PROD = "https://inbox.zoscomm.com";
    private static final String INBOX_MSG_URL_PROD = "https://inbox.zoscomm.com/message";
    private static final int RETRY_DELAY = 3000; // 3 seconds.
    
    private ZDAEventService zdaService = null;
    private String apiKey = null;
    private String password = null;
    private String deviceGuid = null;
    private String messageGuid = null;
    private WebView webView = null;
    
    //=========================================================================
    // Singleton implementation
    //=========================================================================
    
    private static ZdaInboxHelper instance = null;    
    public static synchronized ZdaInboxHelper getInstance()
    {
        if (instance == null)
        {
            instance = new ZdaInboxHelper();           
        }
        
        return instance;
    }
    
    private ZdaInboxHelper()
    {
        
    }
    
    //=========================================================================
    // Public methods
    //=========================================================================
    
    /**
     * Initializes this class.  Must be called before calling any other functions.
     * It is recommended that you call this during app start-up, to minimize
     * delay when showing the web inbox.
     * 
     * @param ctx Your activity's context or the application context.
     * @param apiKey Your ZOS API key.
     * @param password Your ZOS password.
     */
    public synchronized void initialize(Context ctx, String apiKey, String password)
    {
        this.zdaService = ZDAClassFactory.getEventService(ctx.getApplicationContext());  
        this.apiKey = apiKey;
        this.password = password;
        
        doInitialize();
    }
    
    /**
     * Loads the web inbox into the specified WebView. If we are not ready to
     * display the inbox yet, then "The inbox is loading, please wait..." is
     * displayed instead.  Once we are ready to show the inbox, it is shown
     * automatically.
     * 
     * @param webView The WebView to show the web inbox on.
     * @param messageGuid OPTIONAL If specified, we will navigate straight to 
     * the given message instead of the inbox list. If null, then the inbox
     * list is shown.
     */
    public synchronized void showWebInbox(WebView webView, String messageGuid)
    {
        // Make sure that initialize has been called.  If it hasn't, the
        // integration hasn't been done correctly.
        if (this.zdaService == null || this.apiKey == null || this.password == null)
        {
            if (webView != null)
            {
                webView.loadDataWithBaseURL("file:///android_res/raw/", HTML_ERROR, "text/html", "US-ASCII", null);
            }
            return;
        }
        
        this.messageGuid = messageGuid;
        this.webView = webView;
        
        if (deviceGuid == null)
        {
            // Display the 'loading...' text until the guid is available.
            webView.loadDataWithBaseURL("file:///android_res/raw/", HTML_LOADING, "text/html", "US-ASCII", null);
        }
        else
        {
            // We have the guid, we can show the inbox now.
            displayWebInbox();
        }
    }
    
    /**
     * Cancels a previous call to showWebInbox(). This should be called when your
     * activity is destroyed.
     */
    public synchronized void cancelShowWebInbox()
    {
        this.webView = null;
    }
    
    //=========================================================================
    // Private methods
    //=========================================================================
    
    /** Calls authenticate to get a token. */
    private void doInitialize()
    {
        try
        {
            zdaService.authenticateUser(apiKey, password, this);
        }
        catch (Exception e)
        {
            handleError();
        }
    }
    
    /** Actually displays the web inbox once. Should only be called when we have everything we need. */
    private synchronized void displayWebInbox()
    {
        // Belt and braces checks.
        if (apiKey == null || deviceGuid == null || webView == null)
            return;
        
        String url = INBOX_URL_PROD;
        String postData = "API_KEY=" + apiKey + "&device_guid=" + deviceGuid;
        if (messageGuid != null)
        {
            // We have a specific message to show.
            postData += "&id=" + messageGuid;
            url = INBOX_MSG_URL_PROD;
        }
        
        webView.postUrl(url, postData.getBytes());
        webView = null;
    }
    
    /** If anything goes wrong, we attempt initialization again after a short delay. */
    private void handleError()
    {
        new Thread() 
        {
            public void run()
            {
                try
                {
                    Thread.sleep(RETRY_DELAY);
                }
                catch (InterruptedException e){}
                
                doInitialize();
            }
        }.start();
    }
    
    //=========================================================================
    // ZDAEventListener callbacks.
    //=========================================================================
    @Override
    public void onAuthenticationComplete(String token) throws RemoteException
    {       
        try
        {
            // Now get the device GUID.
            zdaService.getProperty(token, DEVICE_GUID_PROPERTY, this);
        }
        catch (Exception e)
        {
            handleError();
        }
    }

    @Override
    public synchronized void onComplete(int actionCode, String param) throws RemoteException 
    {
        try
        {
            int index = param.indexOf('=');
            if (index != -1)
            {
                String name = param.substring(0, index);
                String value = param.substring(index+1, param.length());
                if (name.equals(DEVICE_GUID_PROPERTY))
                {
                    deviceGuid = value;
                }
            }
            
            if (deviceGuid != null)
            {
                if (webView != null)
                {
                    // We have the GUID, and the webview is waiting - show the inbox now.
                    displayWebInbox();
                }
            }
            else
            {
                handleError();
            }
        }
        catch (Exception e)
        {
            handleError();
        }
    }

    @Override
    public void onError(int arg0, String arg1) throws RemoteException
    {
        handleError();
    }

    //
    // These callbacks are not used.
    //
    @Override
    public void onLocationShotResponse(GeoLocation arg0) throws RemoteException {}
    @Override
    public void onLocationUpdate(GeoLocation arg0) throws RemoteException {}
    @Override
    public void onMessageNotify(int arg0) throws RemoteException {}
    @Override
    public void onVersionResponse(String arg0) throws RemoteException {}
    @Override
    public void onXmlResponse(int arg0, String arg1) throws RemoteException {}
}
